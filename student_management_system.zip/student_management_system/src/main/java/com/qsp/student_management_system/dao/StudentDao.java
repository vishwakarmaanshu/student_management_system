package com.qsp.student_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.student_management_system.dto.Student;
import com.qsp.student_management_system.repo.StudentRepo;


@Repository
public class StudentDao {
	
	@Autowired
	private StudentRepo repo;
	
	public Student saveStudent(Student student) {
		return repo.save(student);
		
	}

	public List<Student> saveAll(List<Student> list) {
		return repo.saveAll(list);
	}
	
	public Student findStudentById(int id) {
		Optional<Student> optional=repo.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			return null;
		}
	}
	
	public List<Student> findStudents() {
		return repo.findAll();
	}

	public List<Student> findByPercentageLessThan(double percentage) {
		return repo.findByPercentageLessThan(percentage);
	}

	public List<Student> findByPercentageGreaterThan(double percentage) {
		return repo.findByPercentageGreaterThan(percentage);
	}

	public List<Student> findByPercentageBetween(double percentage1, double percentage2) {
		return repo.findByPercentageBetween(percentage1, percentage2);
	}

	public List<Student> findByName(String name) {
		return repo.findByName(name);
	}
	
	public List<Student> findByFatherName(String fatherName) {
		return repo.findByFatherName(fatherName);
	}

	public List<Student> findByMotherName(String motherName) {
		return repo.findByMotherName(motherName);
	}

	public Student findByPhone(long phone) {
		return repo.findByPhone(phone);
	}

	public Student findByEmail(String email) {
		return repo.findByEmail(email);
	}

	public List<Student> findByAddress(String address) {
		return repo.findByAddress(address);
	}

	public List<Student> findByPercentage(double percentage) {
		return repo.findByPercentage(percentage);
	}

	public Student updateName(int id, String name) {
		Student student = repo.findById(id).get();
		if (student != null) {
			student.setName(name);
			return repo.save(student);
		} else {
			return null;
		}
	}

	public Student updatePhone(int id, long phone) {
		Student student = repo.findById(id).get();
		if (student != null) {
			student.setPhone(phone);
			return repo.save(student);
		} else {
			return null;
		}
	}

	public Student updateAddress(int id, String address) {
		Student student = repo.findById(id).get();
		if (student != null) {
			student.setAddress(address);
			return repo.save(student);
		} else {
			return null;
		}
	}

	public Student updateEmail(int id, String email) {
		Student student = repo.findById(id).get();
		if (student != null) {
			student.setEmail(email);
			return repo.save(student);
		} else {
			return null;
		}
	}

	public Student updatePercentage(int id, double percentage) {
		Student student = repo.findById(id).get();
		if (student != null) {
			student.setPercentage(percentage);
			return repo.save(student);
		} else {
			return null;
		}
	}

	public Student updatePassword(int id, String password) {
		Student student = repo.findById(id).get();
		if (student != null) {
			student.setPassword(password);
			return repo.save(student);
		} else {
			return null;
		}
	}

	public Student updatePasswordByPhone(long phone, String password) {
		Student student = repo.findByPhone(phone);
		if (student != null) {
			student.setPassword(password);
			return repo.save(student);
		} else {
			return null;
		}
	}

	public Student updatePasswordByEmail(String email, String password) {
		Student student = repo.findByEmail(email);
		if (student != null) {
			student.setPassword(password);
			return repo.save(student);
		} else {
			return null;
		}
	}

	public Student updateAll(int id, Student student) {
		Optional<Student> student2 = repo.findById(id);
		if (student2.isPresent()) {
			student.setId(id);
			return repo.save(student);
		} else {
			return null;
		}
	}

	public Student deleteStudent(int id) {
		Optional<Student> student = repo.findById(id);
		if (student.isPresent()) {
			repo.deleteById(id);
			return student.get();
		} else {
			return null;
		}
	}

	public Student deleteStudentByPhone(long phone) {
		Student student = repo.findByPhone(phone);
		if (student != null) {
			repo.delete(student);
			return student;
		} else {
			return null;
		}
	}

	public Student deleteStudentByEmail(String email) {
		Student student = repo.findByEmail(email);
		if (student != null) {
			repo.delete(student);
			return student;
		} else {
			return null;
		}
	}

	public List<Student> deleteAllStudent() {
		repo.deleteAll();
		return null;
	}

	public List<Student> deleteAllStudentByAddress(String address) {
		List<Student> list = repo.findByAddress(address);
		if (list.isEmpty()) {
			return null;
		} else {
			repo.deleteAll(list);
			return list;
		}
	}

	public List<Student> deleteAllStudentByPercentage(double percentage) {
		List<Student> list = repo.findByPercentage(percentage);
		if (list.isEmpty()) {
			return null;
		} else {
			repo.deleteAll(list);
			return list;
		}
	}

	public List<Student> deleteAllStudentByName(String name) {
		List<Student> list = repo.findByName(name);
		if (list.isEmpty()) {
			return null;
		} else {
			repo.deleteAll(list);
			return list;
		}
	}
	
	public List<Student> deleteAllStudentByFatherName(String fatherName) {
		List<Student> list= repo.findByFatherName(fatherName);
		if (list.isEmpty()) {
			return null;
		} else {
			repo.deleteAll(list);
			return list;
		}
	}
	
	public List<Student> deleteAllStudentByMotherName(String motherName) {
		List<Student> list=repo.findByMotherName(motherName);
		if (list.isEmpty()) {
			return null;
		} else {
			repo.deleteAll(list);
			return list;
		}
	}

	public Student loginStudent(String userName) {
		try {
			long phone=Long.parseLong(userName);
			
			return repo.findByPhone(phone);
		} catch (Exception e) {
					
			return repo.findByEmail(userName);		
		}
	}

	

	

	

}
