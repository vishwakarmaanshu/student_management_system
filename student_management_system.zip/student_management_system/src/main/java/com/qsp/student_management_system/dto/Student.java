package com.qsp.student_management_system.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import jakarta.validation.constraints.NotEmpty;

import lombok.Data;

@Entity
@Data
@Table(name = "student_info")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "studentId")
    private int id;
	
	@Column(name = "studentName")
//	@NotBlank(message = "Student name can't be blank")
//	@NotNull(message = "Student name can't be null")
	@NotEmpty(message = "Student name can't be empty")
    private String name;
	
	@Column(name = "studentFatherName")
	@NotBlank(message = "Student name can't be blank")
//	@NotNull(message = "Student name can't be null")
	@NotEmpty(message = "Student name can't be empty")
    private String fatherName;
	
	@Column(name = "studentMotherName")
	@NotBlank(message = "Student name can't be blank")
//	@NotNull(message = "Student name can't be null")
	@NotEmpty(message = "Student name can't be empty")
    private String motherName;
	
	@Column(name = "studentPhone",unique = true)
    private long phone;
	
	@Column(name = "studentAddress")
	
    private String address;
	
	@Column(name = "studentEmail",unique = true)
    private String email;
	
	@Column(name = "studentPassword")
    private String password;
	
	@Column(name = "studentSecuredMarks")
    private int securedMarks;
	
	@Column(name = "studentTotalMarks")
    private int totalMarks;
	
	@Column(name = "studentPercentage")
    private double percentage;
	
	@Column(name = "studentGrade")
    private String grade;
}
