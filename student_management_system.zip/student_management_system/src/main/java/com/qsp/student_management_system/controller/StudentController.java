package com.qsp.student_management_system.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.student_management_system.dto.Student;
import com.qsp.student_management_system.service.StudentService;
import com.qsp.student_management_system.util.ResponseStructure;

@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService service;
	
	@PostMapping
	public ResponseEntity<ResponseStructure<Student>> saveStudent(@RequestBody Student student) {
		return service.saveStudent(student);
	}
	
	@PostMapping("/all")
	public ResponseEntity<ResponseStructure<List<Student>>> saveAll(@RequestBody List<Student> list) {
		return service.saveAll(list);
	}
	
	@GetMapping("/find/id")
	public ResponseEntity<ResponseStructure<Student>> findStudentById(@RequestParam int id) {
		return service.findStudentById(id);
	}
	
	@GetMapping("/find/name")
	public ResponseEntity<ResponseStructure<List<Student>>> findByName(@RequestParam String name) {
		return service.findByName(name);
	}
	
	@GetMapping("/find/fathername")
	public ResponseEntity<ResponseStructure<List<Student>>> findByFatherName(@RequestParam String fatherName) {
		return service.findByFatherName(fatherName);
	}
	
	@GetMapping("/find/mothername")
	public ResponseEntity<ResponseStructure<List<Student>>> findByMotherName(@RequestParam String motherName) {
		return service.findByMotherName(motherName);
	}

	@GetMapping("/find/phone")
	public ResponseEntity<ResponseStructure<Student>> findByPhone(@RequestParam long phone) {
		return service.findByPhone(phone);
	}

	@GetMapping("/find/email")
	public ResponseEntity<ResponseStructure<Student>> findByEmail(@RequestParam String email) {
		return service.findByEmail(email);
	}

	@GetMapping("/find/address")
	public ResponseEntity<ResponseStructure<List<Student>>> findByAddress(@RequestParam String address) {
		return service.findByAddress(address);
	}

	@GetMapping("/find/percentage")
	public ResponseEntity<ResponseStructure<List<Student>>> findByPercentage(@RequestParam double percentage) {
		return service.findByPercentage(percentage);
	}
	
	@GetMapping("/find/all")
	public ResponseEntity<ResponseStructure<List<Student>>> findStudents() {
		return service.findStudents();
	}
	
	@GetMapping("/percentage/lessthan")
	public ResponseEntity<ResponseStructure<List<Student>>> findByPercentageLessThan(double percentage) {
		return service.findByPercentageLessThan(percentage);
	}

	@GetMapping("/percentage/greaterthan")
	public ResponseEntity<ResponseStructure<List<Student>>> findByPercentageGreaterThan(double percentage) {
		return service.findByPercentageGreaterThan(percentage);
	}

	@GetMapping("/percentage/between")
	public ResponseEntity<ResponseStructure<List<Student>>> findBySalaryBetween(double percentage1, double percentage2) {
		return service.findByPercentageBetween(percentage1, percentage2);
	}
	
	@PatchMapping("/update/name")
	public ResponseEntity<ResponseStructure<Student>> updateName(@RequestParam int id, @RequestParam String name) {
		return service.updateName(id, name);
	}

	@PatchMapping("/update/phone")
	public ResponseEntity<ResponseStructure<Student>> updatePhone(@RequestParam int id, @RequestParam long phone) {
		return service.updatePhone(id, phone);
	}

	@PatchMapping("/update/address")
	public ResponseEntity<ResponseStructure<Student>> updateAddress(@RequestParam int id, @RequestParam String address) {
		return service.updateAddress(id, address);
	}

	@PatchMapping("/update/email")
	public ResponseEntity<ResponseStructure<Student>> updateEmail(@RequestParam int id, @RequestParam String email) {
		return service.updateEmail(id, email);
	}

	@PatchMapping("/update/percentage")
	public ResponseEntity<ResponseStructure<Student>> updatePercentage(@RequestParam int id, @RequestParam double percentage) {
		return service.updatePercentage(id, percentage);
	}

	@PatchMapping("/update/password")
	public ResponseEntity<ResponseStructure<Student>> updatePassword(@RequestParam int id, @RequestParam String password) {
		return service.updatePassword(id, password);
	}

	@PatchMapping("/update/password/byphone")
	public ResponseEntity<ResponseStructure<Student>> updatePasswordByPhone(@RequestParam long phone, @RequestParam String password) {
		return service.updatePasswordByPhone(phone, password);
	}

	@PatchMapping("/update/password/byemail")
	public ResponseEntity<ResponseStructure<Student>> updatePassword(@RequestParam String email, @RequestParam String password) {
		return service.updatePasswordByEmail(email, password);
	}

	@PutMapping("/update/all")
	public ResponseEntity<ResponseStructure<Student>> updateAll(@RequestParam int id, @RequestBody Student student) {
		return service.updateAll(id, student);
	}

	@DeleteMapping("/delete/byid")
	public ResponseEntity<ResponseStructure<Student>> deleteEmployee(@RequestParam int id) {
		return service.deleteStudent(id);
	}

	@DeleteMapping("/delete/byphone")
	public ResponseEntity<ResponseStructure<Student>> deleteEmployee(@RequestParam long phone) {
		return service.deleteStudentByPhone(phone);
	}

	@DeleteMapping("/delete/byemail")
	public ResponseEntity<ResponseStructure<Student>> deleteEmail(@RequestParam String email) {
		return service.deleteStudentByEmail(email);
	}

	@DeleteMapping("/delete/all")
	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudent() {
		return service.deleteAllStudent();
	}

	@DeleteMapping("/delete/all/address")
	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByAddress(@RequestParam String address) {
		return service.deleteAllStudentByAddress(address);
	}

	@DeleteMapping("/delete/all/percentage")
	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByPercentage(@RequestParam double percentage) {
		return service.deleteAllStudentByPercentage(percentage);
	}
	
	@DeleteMapping("/delete/all/fathername")
	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByFatherName(String fatherName) {
		return service.deleteAllStudentByFatherName(fatherName);
	}
	
	@DeleteMapping("/delete/all/mothername")
	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByMotherName(String fatherName) {
		return service.deleteAllStudentByMotherName(fatherName);
	}

	@DeleteMapping("/delete/all/name")
	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByName(@RequestParam String name) {
		return service.deleteAllStudentByName(name);
	}

	@GetMapping("/login")
	public ResponseEntity<ResponseStructure<Student>> loginStudent(@RequestParam String userName, @RequestParam String password) {
		return service.loginStudent(userName, password);
	}
	
	
	
	
	
}
