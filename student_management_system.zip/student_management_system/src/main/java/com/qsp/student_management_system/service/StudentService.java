package com.qsp.student_management_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.qsp.student_management_system.dao.StudentDao;
import com.qsp.student_management_system.dto.Student;
import com.qsp.student_management_system.exception.EmailNotFoundException;
import com.qsp.student_management_system.exception.IdNotFoundException;
import com.qsp.student_management_system.exception.NoDataFoundException;
import com.qsp.student_management_system.exception.PhoneNumberNotFoundException;
import com.qsp.student_management_system.util.ResponseStructure;

@Service
public class StudentService {

	@Autowired
	private StudentDao dao;
	
	public ResponseEntity<ResponseStructure<Student>> saveStudent(Student student) {
		int securedMarks=student.getSecuredMarks();
		int totalMarks=student.getTotalMarks();
		double percentage=((securedMarks*100.0)/totalMarks);
		student.setPercentage(percentage);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		if (securedMarks<=totalMarks) {
			if (percentage>=85.0) {
				student.setGrade("Distinction");
			} else if (percentage>=70.0 && percentage<85.0) {
				student.setGrade("First Class");
			} else if (percentage>=49.0 && percentage<70.0) {
				student.setGrade("Second Class");
			} else if (percentage>=35.0 && percentage<49.0) {
				student.setGrade("Pass");
			} else {
				student.setGrade("Fail");
			}
			
			structure.setStatus(HttpStatus.OK.value());
			structure.setMessage("saved successful");
			structure.setData(dao.saveStudent(student));
			return new ResponseEntity<ResponseStructure<Student>>(structure, HttpStatus.OK);
		}
		else {	
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("Invalid Marks");
			structure.setData(dao.saveStudent(student));
			return new ResponseEntity<ResponseStructure<Student>>(structure, HttpStatus.NOT_FOUND);
		}
		
	}
	
	public ResponseEntity<ResponseStructure<List<Student>>> saveAll(List<Student> list) {
		
		for (Student student : list) {
			int securedMarks=student.getSecuredMarks();
			int totalMarks=student.getTotalMarks();
			double percentage=((securedMarks*100.0)/totalMarks);
			student.setPercentage(percentage);
			ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
			if (securedMarks<=totalMarks) {
				if (percentage>85.0) {
					student.setGrade("Distinction");
				} else if (percentage>=70.0 && percentage<85.0) {
					student.setGrade("First Class");
				} else if (percentage>=49.0 && percentage<70.0) {
					student.setGrade("Second Class");
				} else if (percentage>=35.0 && percentage<49.0) {
					student.setGrade("Pass");
				} else {
					student.setGrade("Fail");
				}
				
				structure.setStatus(HttpStatus.OK.value());
				structure.setMessage("saved successful");
				structure.setData(dao.saveAll(list));
				return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.OK);
			}
			else {
			
				throw new NoDataFoundException("List is empty");
			}
		}
		return null;
	}
	
	public ResponseEntity<ResponseStructure<Student>> findStudentById(int id) {
		Student student=dao.findStudentById(id);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		if (student!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.FOUND);
		} else {
			throw new IdNotFoundException("Student with id "+id+" not found");
		}
	}
	
	public ResponseEntity<ResponseStructure<List<Student>>> findStudents() {
		List<Student> list=dao.findStudents();
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.FOUND);
		} else {
			throw new NoDataFoundException("Student no data found");
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> findByPercentageLessThan(double percentage) {
		List<Student> list=dao.findByPercentageLessThan(percentage);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.FOUND);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> findByPercentageGreaterThan(double percentage) {
		List<Student> list=dao.findByPercentageGreaterThan(percentage);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.FOUND);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> findByPercentageBetween(double percentage1, double percentage2) {
		List<Student> list=dao.findByPercentageBetween(percentage1,percentage2);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.FOUND);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> findByName(String name) {
		List<Student> list=dao.findByName(name);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.FOUND);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<ResponseStructure<List<Student>>> findByFatherName(String fatherName) {
		List<Student> list=dao.findByFatherName(fatherName);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.FOUND);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> findByMotherName(String motherName) {
		List<Student> list=dao.findByMotherName(motherName);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.FOUND);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<Student>> findByPhone(long phone) {
		Student student=dao.findByPhone(phone);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		if (student!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.FOUND);
		} else {
			throw new PhoneNumberNotFoundException("Student not found with "+phone);
		}
	}

	public ResponseEntity<ResponseStructure<Student>> findByEmail(String email) {
		Student student=dao.findByEmail(email);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		if (student!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.FOUND);
		} else {
			throw new EmailNotFoundException("Student with email "+email+" not found");
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> findByAddress(String address) {
		List<Student> list=dao.findByAddress(address);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.FOUND);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> findByPercentage(double percentage) {
		List<Student> list=dao.findByPercentage(percentage);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list!=null) {
			structure.setStatus(HttpStatus.FOUND.value());
			structure.setMessage("found successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.FOUND);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<Student>> updateName(int id, String name) {
		Student student=dao.updateName(id, name);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("update successful");
		structure.setData(student);
		return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Student>> updatePhone(int id, long phone) {
		Student student=dao.updatePhone(id, phone);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("update successful");
		structure.setData(student);
		return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Student>> updateAddress(int id, String address) {
		Student student=dao.updateAddress(id, address);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("update successful");
		structure.setData(student);
		return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Student>> updateEmail(int id, String email) {
		Student student=dao.updateEmail(id, email);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("update successful");
		structure.setData(student);
		return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Student>> updatePercentage(int id, double percentage) {
		Student student= dao.updatePercentage(id, percentage);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("update successful");
		structure.setData(student);
		return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Student>> updatePassword(int id, String password) {
		Student student=dao.updatePassword(id,password);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("update successful");
		structure.setData(student);
		return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Student>> updatePasswordByPhone(long phone, String password) {
		Student student=dao.updatePasswordByPhone(phone, password);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("update successful");
		structure.setData(student);
		return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Student>> updatePasswordByEmail(String email, String password) {
		Student student=dao.updatePasswordByEmail(email, password);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("update successful");
		structure.setData(student);
		return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
	}
	
	public ResponseEntity<ResponseStructure<Student>> updateAll(int id, Student student) {
		Student student2=dao.updateAll(id, student);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("update successful");
		structure.setData(student2);
		return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<Student>> deleteStudent(int id) {
		Student student=dao.deleteStudent(id);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		if (student!=null) {
			structure.setStatus(HttpStatus.OK.value());
			structure.setMessage("delete successful");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("id not found");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<Student>> deleteStudentByPhone(long phone) {
		Student student=dao.deleteStudentByPhone(phone);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		if (student!=null) {
			structure.setStatus(HttpStatus.OK.value());
			structure.setMessage("delete successful");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("phone number not found");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<Student>> deleteStudentByEmail(String email) {
		Student student=dao.deleteStudentByEmail(email);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		if (student!=null) {
			structure.setStatus(HttpStatus.OK.value());
			structure.setMessage("delete successful");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.OK);
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("Email id not found");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudent() {
		List<Student> list=dao.deleteAllStudent();
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		structure.setStatus(HttpStatus.OK.value());
		structure.setMessage("deleted successfully");
		structure.setData(list);
		return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.OK);
	}

	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByAddress(String address) {
		List<Student> list=dao.deleteAllStudentByAddress(address);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list.isEmpty()) {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("Address not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		} else {
			structure.setStatus(HttpStatus.OK.value());
			structure.setMessage("delete successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.OK);
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByPercentage(double percentage) {
		List<Student> list=dao.deleteAllStudentByPercentage(percentage);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list.isEmpty()) {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("invalid percentage");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		} else {
			structure.setStatus(HttpStatus.OK.value());
			structure.setMessage("delete successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.OK);
		}
	}

	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByName(String name) {
		List<Student> list=dao.deleteAllStudentByName(name);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list.isEmpty()) {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("Student not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		} else {
			structure.setStatus(HttpStatus.OK.value());
			structure.setMessage("delete successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.OK);
		}
	}
	
	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByFatherName(String fatherName) {
		List<Student> list=dao.deleteAllStudentByFatherName(fatherName);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list.isEmpty()) {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("Student not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		} else {
			structure.setStatus(HttpStatus.OK.value());
			structure.setMessage("delete successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.OK);
		}
	}
	
	public ResponseEntity<ResponseStructure<List<Student>>> deleteAllStudentByMotherName(String motherName) {
		List<Student> list=dao.deleteAllStudentByMotherName(motherName);
		ResponseStructure<List<Student>> structure=new ResponseStructure<List<Student>>();
		if (list.isEmpty()) {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("Student not found");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.NOT_FOUND);
		} else {
			structure.setStatus(HttpStatus.OK.value());
			structure.setMessage("delete successful");
			structure.setData(list);
			return new ResponseEntity<ResponseStructure<List<Student>>>(structure,HttpStatus.OK);
		}
	}

	public ResponseEntity<ResponseStructure<Student>> loginStudent(String userName, String password) {
		Student student=dao.loginStudent(userName);
		ResponseStructure<Student> structure=new ResponseStructure<Student>();
		if (student!=null) {
			if (student.getPassword().equals(password)) {
				structure.setStatus(HttpStatus.FOUND.value());
				structure.setMessage("Login successful");
				structure.setData(student);
				return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.FOUND);
			} else {
				structure.setStatus(HttpStatus.NOT_FOUND.value());
				structure.setMessage("Invalid password");
				structure.setData(student);
				return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.NOT_FOUND);
			}
		} else {
			structure.setStatus(HttpStatus.NOT_FOUND.value());
			structure.setMessage("Student not found");
			structure.setData(student);
			return new ResponseEntity<ResponseStructure<Student>>(structure,HttpStatus.NOT_FOUND);
		}
	}

	
}
